# KARAR v2 — Consolidated Release Gate

The source has undergone the available source-level security cleanup.

## Must still be proven in the complete development repository
- dependency installation with a committed lockfile
- TypeScript typecheck
- lint
- production build
- backend entitlement verification
- iOS StoreKit sandbox
- Google Play Billing internal test
- real-device end-to-end tests
- final legal/tax/store review

**No store submission should be made until those external/runtime gates pass.**
