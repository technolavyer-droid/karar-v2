import type { CaseFile, CaseVerdict, TheoryPin } from "./types";

export interface ScoreInput {
  file: CaseFile;
  suspectId: string;
  keyEvidenceId: string;
  confidence: number;
  hintsUsed: number;
  viewed: string[];
  pins: TheoryPin[];
}

export function scoreVerdict(input: ScoreInput): Omit<
  CaseVerdict,
  "lockedAt"
> {
  const { file, suspectId, keyEvidenceId, confidence, hintsUsed, viewed, pins } =
    input;
  const personCorrect = suspectId === file.culpritId;
  const evidenceCorrect = keyEvidenceId === file.keyEvidenceId;
  const correct = personCorrect && evidenceCorrect;

  const criticalIds = file.evidence.filter((e) => e.isCritical).map((e) => e.id);
  const criticalFound = criticalIds.filter((id) => viewed.includes(id)).length;

  const contradictionIds = file.evidence
    .filter((e) => e.contradictsCharacterId)
    .map((e) => e.id);
  const contradictions = contradictionIds.filter((id) =>
    viewed.includes(id),
  ).length;

  const pinnedRight = pins.some(
    (p) => p.characterId === file.culpritId && p.evidenceId === file.keyEvidenceId,
  );

  let xp = 0;
  if (correct) xp += 100;
  else if (personCorrect) xp += 70;
  else if (evidenceCorrect) xp += 30;
  else xp += 10;

  xp += Math.min(criticalFound, 3) * 10;
  if (contradictions > 0) xp += 20;
  if (pinnedRight) xp += 20;
  if (correct && hintsUsed === 0) xp += 50;
  xp -= hintsUsed * 20;
  if (confidence >= 80 && correct) xp += 10;
  if (xp < 5) xp = 5;

  return {
    suspectId,
    keyEvidenceId,
    confidence,
    correct,
    personCorrect,
    evidenceCorrect,
    xpEarned: xp,
    hintsUsed,
    criticalFound,
    contradictions,
  };
}
