import type { PlayerSave } from "./types";
import { CASES } from "@/data/cases";

export interface BadgeDef {
  id: string;
  name: string;
  blurb: string;
  check: (s: PlayerSave) => boolean;
}

export const BADGES: BadgeDef[] = [
  {
    id: "ilk-dosya",
    name: "İlk Dosya",
    blurb: "İlk vakayı kilitledin.",
    check: (s) => Object.keys(s.solved).length >= 1,
  },
  {
    id: "keskin-goz",
    name: "Keskin Göz",
    blurb: "Beş kritik delili gördün.",
    check: (s) =>
      Object.values(s.solved).reduce((n, v) => n + v.criticalFound, 0) >= 5,
  },
  {
    id: "sogukkanli",
    name: "Soğukkanlı",
    blurb: "Üç vakayı ipucu kullanmadan doğru çözdün.",
    check: (s) =>
      Object.values(s.solved).filter((v) => v.correct && v.hintsUsed === 0)
        .length >= 3,
  },
  {
    id: "zaman-avcisi",
    name: "Zaman Avcısı",
    blurb: "İki zaman çizelgesi vakasını doğru kilitledin.",
    check: (s) => {
      const timed = new Set(
        CASES.filter((c) => c.timeline.length >= 5).map((c) => c.id),
      );
      return Object.entries(s.solved).filter(
        ([id, v]) => timed.has(id) && v.correct,
      ).length >= 2;
    },
  },
  {
    id: "bulmacaci",
    name: "Bulmacacı",
    blurb: "Sekiz vakayı kapattın.",
    check: (s) => Object.keys(s.solved).length >= 8,
  },
  {
    id: "seri-3",
    name: "Üç Gün",
    blurb: "Üç günlük seri tutturdun.",
    check: (s) => s.streak >= 3,
  },
  {
    id: "seri-7",
    name: "Bir Hafta",
    blurb: "Yedi günlük seri.",
    check: (s) => s.streak >= 7,
  },
  {
    id: "sezon-1",
    name: "Veyra'nın Gölgesi",
    blurb: "Sezon 1'in ücretsiz vakalarını bitirdin.",
    check: (s) =>
      CASES.filter((c) => !c.isPremium).every((c) => s.solved[c.id]),
  },
  {
    id: "mukemmel",
    name: "İlk Deneme",
    blurb: "Bir vakayı ilk kilitlemede, ipucusuz ve doğru kapattın.",
    check: (s) =>
      Object.values(s.solved).some(
        (v) => v.correct && v.hintsUsed === 0 && v.evidenceCorrect,
      ),
  },
];

export function unlockedBadges(s: PlayerSave): string[] {
  return BADGES.filter((b) => b.check(s)).map((b) => b.id);
}
