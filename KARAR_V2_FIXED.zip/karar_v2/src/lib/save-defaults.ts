import type { CaseVerdict, FrameId, PlayerSave, TheoryPin } from "./types";

export const DEFAULT_SAVE: PlayerSave = {
  version: 1,
  onboardingDone: false,
  ageConfirmed: false,
  displayName: "Analist",
  xp: 0,
  streak: 0,
  lastPlayDate: null,
  solved: {},
  viewedEvidence: {},
  hintsUsed: {},
  pins: {},
  notes: {},
  badges: [],
  premium: false,
  premiumSince: null,
  frames: ["none"],
  activeFrame: "none",
  adsRemoved: false,
};

export interface GameState extends PlayerSave {
  hydrated: boolean;
  setHydrated: () => void;
  confirmAge: () => void;
  completeOnboarding: (name: string) => void;
  setName: (name: string) => void;
  markViewed: (caseId: string, evidenceId: string) => void;
  useHint: (caseId: string) => number;
  setPins: (caseId: string, pins: TheoryPin[]) => void;
  setNote: (caseId: string, note: string) => void;
  lockVerdict: (caseId: string, verdict: CaseVerdict) => string[];
  buyFrame: (id: FrameId) => void;
  setFrame: (id: FrameId) => void;
  /**
   * PREVIEW-ONLY local entitlement flag. This sets `premium` in the
   * client-persisted save with NO server verification — acceptable only for
   * the web preview's simulated checkout. Before store release this must be
   * replaced by a flow where the store's real receipt (StoreKit / Play
   * Billing) is verified server-side and `premium` is derived from that
   * server response, never granted directly from a client call. See
   * FINAL_RELEASE_CHECKLIST.md item "Native iOS/Android billing verification".
   */
  buyPremium: () => void;
  resetSave: () => void;
}
