import { CASES } from "@/data/cases";
import type { PlayerSave } from "./types";

export function isUnlocked(caseId: string, save: PlayerSave): boolean {
  const file = CASES.find((c) => c.id === caseId);
  if (!file) return false;
  if (file.isPremium && !save.premium) return false;
  const free = CASES.filter((c) => !c.isPremium);
  const idx = free.findIndex((c) => c.id === caseId);
  if (idx <= 0) return true;
  if (file.isPremium) return save.premium;
  const prev = free[idx - 1];
  return Boolean(save.solved[prev.id]);
}

export function nextPlayable(save: PlayerSave) {
  return (
    CASES.find((c) => !c.isPremium && !save.solved[c.id] && isUnlocked(c.id, save)) ??
    CASES.find((c) => c.isPremium && save.premium && !save.solved[c.id]) ??
    null
  );
}

export function accuracy(save: PlayerSave): number | null {
  const vals = Object.values(save.solved);
  if (!vals.length) return null;
  const ok = vals.filter((v) => v.correct).length;
  return Math.round((ok / vals.length) * 100);
}

export function seasonPct(save: PlayerSave): number {
  const n = CASES.filter((c) => !c.isPremium).length;
  const d = CASES.filter((c) => !c.isPremium && save.solved[c.id]).length;
  return Math.round((d / n) * 100);
}
