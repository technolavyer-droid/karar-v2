import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { TheoryPin } from "./types";
import { unlockedBadges } from "./badges";
import { todayKey, yesterdayKey } from "./utils";
import { DEFAULT_SAVE, type GameState } from "./save-defaults";

function touchStreak(s: { streak: number; lastPlayDate: string | null }) {
  const today = todayKey();
  if (s.lastPlayDate === today) return { streak: s.streak, lastPlayDate: today };
  if (s.lastPlayDate === yesterdayKey()) {
    return { streak: s.streak + 1, lastPlayDate: today };
  }
  return { streak: 1, lastPlayDate: today };
}

export const useGame = create<GameState>()(
  persist(
    (set, get) => ({
      ...DEFAULT_SAVE,
      hydrated: false,
      setHydrated: () => set({ hydrated: true }),
      confirmAge: () => set({ ageConfirmed: true }),
      completeOnboarding: (name) =>
        set({
          onboardingDone: true,
          displayName: name.trim() || "Analist",
        }),
      setName: (name) => set({ displayName: name.trim() || "Analist" }),
      markViewed: (caseId, evidenceId) => {
        const prev = get().viewedEvidence[caseId] ?? [];
        if (prev.includes(evidenceId)) return;
        set({
          viewedEvidence: {
            ...get().viewedEvidence,
            [caseId]: [...prev, evidenceId],
          },
        });
      },
      useHint: (caseId) => {
        const n = Math.min((get().hintsUsed[caseId] ?? 0) + 1, 3);
        set({ hintsUsed: { ...get().hintsUsed, [caseId]: n } });
        return n;
      },
      setPins: (caseId, pins: TheoryPin[]) =>
        set({ pins: { ...get().pins, [caseId]: pins } }),
      setNote: (caseId, note) =>
        set({ notes: { ...get().notes, [caseId]: note } }),
      lockVerdict: (caseId, verdict) => {
        const prev = get();
        if (prev.solved[caseId]) return [];
        const streak = touchStreak(prev);
        const nextSave = {
          version: prev.version,
          onboardingDone: prev.onboardingDone,
          ageConfirmed: prev.ageConfirmed,
          displayName: prev.displayName,
          xp: prev.xp + verdict.xpEarned,
          streak: streak.streak,
          lastPlayDate: streak.lastPlayDate,
          solved: { ...prev.solved, [caseId]: verdict },
          viewedEvidence: prev.viewedEvidence,
          hintsUsed: prev.hintsUsed,
          pins: prev.pins,
          notes: prev.notes,
          badges: prev.badges,
          premium: prev.premium,
          premiumSince: prev.premiumSince,
          frames: prev.frames,
          activeFrame: prev.activeFrame,
          adsRemoved: prev.adsRemoved,
        };
        const badges = unlockedBadges(nextSave);
        const fresh = badges.filter((id) => !prev.badges.includes(id));
        set({ ...nextSave, badges });
        return fresh;
      },
      buyFrame: (id) => {
        const frames = get().frames.includes(id)
          ? get().frames
          : [...get().frames, id];
        set({ frames, activeFrame: id });
      },
      // PREVIEW-ONLY: see the doc comment on `buyPremium` in
      // `save-defaults.ts`. Do not treat this as production entitlement.
      buyPremium: () => {
        if (get().premium) return;
        set({ premium: true, premiumSince: new Date().toISOString() });
      },
      setFrame: (id) => {
        if (get().frames.includes(id)) set({ activeFrame: id });
      },
      resetSave: () => set({ ...DEFAULT_SAVE, hydrated: true, ageConfirmed: true }),
    }),
    {
      name: "karar-save-v1",
      storage: createJSONStorage(() => localStorage),
      version: 1,
      partialize: (s) => ({
        version: s.version,
        onboardingDone: s.onboardingDone,
        ageConfirmed: s.ageConfirmed,
        displayName: s.displayName,
        xp: s.xp,
        streak: s.streak,
        lastPlayDate: s.lastPlayDate,
        solved: s.solved,
        viewedEvidence: s.viewedEvidence,
        hintsUsed: s.hintsUsed,
        pins: s.pins,
        notes: s.notes,
        badges: s.badges,
        premium: s.premium,
        premiumSince: s.premiumSince,
        frames: s.frames,
        activeFrame: s.activeFrame,
        adsRemoved: s.adsRemoved,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated();
      },
    },
  ),
);
