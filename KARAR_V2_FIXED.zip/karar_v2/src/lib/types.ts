export type EvidenceKind =
  | "camera"
  | "statement"
  | "physical"
  | "document"
  | "timeline"
  | "receipt";

export type CaseCategory = "gizem" | "kayip" | "sabotaj" | "mantik" | "hirsizlik";

export type Difficulty = 1 | 2 | 3 | 4;

export interface Character {
  id: string;
  name: string;
  role: string;
  bio: string;
  statement: string;
}

export interface Evidence {
  id: string;
  kind: EvidenceKind;
  title: string;
  time?: string;
  body: string;
  isCritical: boolean;
  isRedHerring: boolean;
  contradictsCharacterId?: string;
}

export interface TimelineBeat {
  time: string;
  text: string;
  evidenceId?: string;
}

export interface CommunityTheory {
  handle: string;
  suspectId: string;
  text: string;
  pct: number;
}

export interface CaseFile {
  id: string;
  number: string;
  title: string;
  location: string;
  category: CaseCategory;
  difficulty: Difficulty;
  durationMin: number;
  isPremium: boolean;
  isTutorial?: boolean;
  seasonIndex: number;
  hasSeal: boolean;
  summary: string;
  briefing: string;
  characters: Character[];
  evidence: Evidence[];
  timeline: TimelineBeat[];
  culpritId: string;
  keyEvidenceId: string;
  solution: string;
  closing: string;
  hints: [string, string, string];
  community: CommunityTheory[];
}

export interface CaseVerdict {
  suspectId: string;
  keyEvidenceId: string;
  confidence: number;
  correct: boolean;
  personCorrect: boolean;
  evidenceCorrect: boolean;
  xpEarned: number;
  hintsUsed: number;
  criticalFound: number;
  contradictions: number;
  lockedAt: string;
}

export interface TheoryPin {
  evidenceId: string;
  characterId: string;
}

export type FrameId = "none" | "dedektif" | "gizemci" | "gece";

export interface PlayerSave {
  version: number;
  onboardingDone: boolean;
  ageConfirmed: boolean;
  displayName: string;
  xp: number;
  streak: number;
  lastPlayDate: string | null;
  solved: Record<string, CaseVerdict>;
  viewedEvidence: Record<string, string[]>;
  hintsUsed: Record<string, number>;
  pins: Record<string, TheoryPin[]>;
  notes: Record<string, string>;
  badges: string[];
  premium: boolean;
  premiumSince: string | null;
  frames: FrameId[];
  activeFrame: FrameId;
  adsRemoved: boolean;
}
