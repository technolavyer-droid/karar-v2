export interface Rank {
  id: string;
  name: string;
  minXp: number;
  blurb: string;
}

export const RANKS: Rank[] = [
  { id: "caylak", name: "Çaylak", minXp: 0, blurb: "Dosyayı ilk kez açıyorsun." },
  { id: "gozlemci", name: "Gözlemci", minXp: 80, blurb: "Küçük ayrıntıları kaçırmıyorsun." },
  { id: "analist", name: "Analist", minXp: 400, blurb: "Çelişkileri sistematik tarıyorsun." },
  { id: "dedektif", name: "Dedektif", minXp: 900, blurb: "Teori kuruyor, delili tartıyorsun." },
  { id: "uzman", name: "Uzman", minXp: 1600, blurb: "Gürültüyü ayıklamakta ustasın." },
  { id: "usta", name: "Usta", minXp: 2500, blurb: "Zaman çizelgesi senin dilin." },
  { id: "bas", name: "Baş Analist", minXp: 3600, blurb: "Veyra'nın gölgesini okuyorsun." },
];

export function rankForXp(xp: number): Rank {
  let current = RANKS[0];
  for (const r of RANKS) {
    if (xp >= r.minXp) current = r;
  }
  return current;
}

export function nextRank(xp: number): Rank | null {
  const cur = rankForXp(xp);
  const i = RANKS.findIndex((r) => r.id === cur.id);
  return RANKS[i + 1] ?? null;
}

export function rankProgress(xp: number): number {
  const cur = rankForXp(xp);
  const nxt = nextRank(xp);
  if (!nxt) return 1;
  return (xp - cur.minXp) / (nxt.minXp - cur.minXp);
}
