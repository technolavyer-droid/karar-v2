import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Clock, Flame, Lock } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { FictionBanner } from "@/components/disclaimer";
import { RankBar } from "@/components/rank-bar";
import { CASES, CATEGORY_LABEL, DIFFICULTY_LABEL } from "@/data/cases";
import { nextPlayable, seasonPct } from "@/lib/progress";
import { useGame } from "@/lib/store";
import { formatCountdown, msUntilMidnight } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const save = useGame();
  const [left, setLeft] = useState(msUntilMidnight());

  useEffect(() => {
    const t = window.setInterval(() => setLeft(msUntilMidnight()), 1000);
    return () => window.clearInterval(t);
  }, []);

  if (!save.ageConfirmed || !save.onboardingDone) {
    return <Navigate to="/onboarding" />;
  }

  const today = nextPlayable(save);
  const lastSolved = Object.entries(save.solved).sort(
    (a, b) => b[1].lockedAt.localeCompare(a[1].lockedAt),
  )[0];
  const lastFile = lastSolved ? CASES.find((c) => c.id === lastSolved[0]) : null;

  return (
    <AppShell>
      <div className="stagger-in space-y-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink">
              Günün dosyası
            </p>
            <h1 className="mt-1 font-display text-3xl">Merhaba, {save.displayName}</h1>
          </div>
          <div className="rounded-md bg-raised px-3 py-2 text-right shadow-[var(--shadow-border)]">
            <p className="inline-flex items-center gap-1 text-xs text-muted">
              <Flame className="size-3.5 text-warn" />
              <span className="tabular-nums">{save.streak}</span>
            </p>
            <p className="text-[10px] text-subtle">günlük seri</p>
          </div>
        </div>

        {today ? (
          <article className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
            <p className="font-mono text-[11px] tracking-[0.16em] text-ink">
              {today.number}
            </p>
            <h2 className="mt-2 font-display text-3xl leading-tight">{today.title}</h2>
            <p className="mt-2 text-sm text-muted">{today.location}</p>
            <p className="mt-3 leading-relaxed text-fg/90">{today.summary}</p>
            <div className="mt-4 flex flex-wrap gap-2 text-[11px] text-subtle">
              <span className="rounded-sm bg-raised px-2 py-1">
                {CATEGORY_LABEL[today.category]}
              </span>
              <span className="rounded-sm bg-raised px-2 py-1">
                {DIFFICULTY_LABEL[today.difficulty]}
              </span>
              <span className="inline-flex items-center gap-1">
                <Clock className="size-3" />
                {today.durationMin} dk
              </span>
              {today.hasSeal && <span className="text-ink">Mühür izi</span>}
            </div>
            <Link to="/vaka/$id" params={{ id: today.id }} className="mt-5 block">
              <Button size="lg" className="w-full">
                Dosyayı aç
              </Button>
            </Link>
          </article>
        ) : (
          <article className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
            <p className="font-mono text-[11px] tracking-[0.16em] text-ink">
              Bugün kapandı
            </p>
            <h2 className="mt-2 font-display text-3xl">Yeni dosya yarın</h2>
            <p className="mt-2 inline-flex items-center gap-2 font-mono text-lg tabular-nums text-muted">
              <Clock className="size-4" />
              {formatCountdown(left)}
            </p>
            {lastFile && (
              <p className="mt-3 text-sm text-muted">Son kilit: {lastFile.title}</p>
            )}
            <div className="mt-5 grid grid-cols-2 gap-2">
              <Link to="/vakalar">
                <Button variant="secondary" className="w-full">
                  Arşiv
                </Button>
              </Link>
              <Link to="/sezon">
                <Button variant="secondary" className="w-full">
                  Sezon
                </Button>
              </Link>
            </div>
          </article>
        )}

        <RankBar xp={save.xp} />

        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl">Sezon 1</h2>
            <span className="font-mono text-sm tabular-nums text-muted">
              %{seasonPct(save)}
            </span>
          </div>
          <p className="mt-1 text-sm text-muted">Veyra'nın Gölgesi</p>
          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-raised">
            <div
              className="h-full bg-ink"
              style={{ width: `${seasonPct(save)}%` }}
            />
          </div>
          <Link
            to="/sezon"
            className="mt-3 inline-block text-sm text-fg underline-offset-2 hover:underline"
          >
            Hikâyeyi gör
          </Link>
        </section>

        {!save.premium && (
          <Link
            to="/magaza"
            className="flex items-center justify-between rounded-xl bg-raised px-4 py-3 shadow-[var(--shadow-border)]"
          >
            <div>
              <p className="text-sm font-medium">Vaka Plus</p>
              <p className="text-xs text-muted">
                Ek vakalar, gelişmiş tahta, reklamsız
              </p>
            </div>
            <Lock className="size-4 text-subtle" />
          </Link>
        )}

        <FictionBanner />
      </div>
    </AppShell>
  );
}
