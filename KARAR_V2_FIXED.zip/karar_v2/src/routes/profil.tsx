import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { RankBar } from "@/components/rank-bar";
import { Button } from "@/components/ui/button";
import { Seal } from "@/components/seal";
import { BADGES } from "@/lib/badges";
import { accuracy } from "@/lib/progress";
import { useGame } from "@/lib/store";
import { cn, formatXp } from "@/lib/utils";
import { CASES } from "@/data/cases";

export const Route = createFileRoute("/profil")({ component: Profil });

const FRAMES: Record<string, string> = {
  none: "Yok",
  dedektif: "Dedektif",
  gizemci: "Gizemci",
  gece: "Gece Avcısı",
};

function Profil() {
  const save = useGame();
  const acc = accuracy(save);
  const solved = Object.keys(save.solved).length;

  return (
    <AppShell>
      <div className="space-y-6">
        <header className="flex items-center gap-4">
          <div
            className={cn(
              "flex size-16 items-center justify-center rounded-full bg-raised",
              save.activeFrame === "dedektif" && "ring-2 ring-ink",
              save.activeFrame === "gizemci" && "ring-2 ring-fg/40",
              save.activeFrame === "gece" && "ring-2 ring-subtle",
            )}
          >
            <Seal size={28} />
          </div>
          <div>
            <h1 className="font-display text-3xl">{save.displayName}</h1>
            <p className="text-sm text-muted">{FRAMES[save.activeFrame]} çerçevesi</p>
          </div>
        </header>

        <RankBar xp={save.xp} />

        <dl className="grid grid-cols-3 gap-2">
          <Stat label="Vaka" value={`${solved}/${CASES.length}`} />
          <Stat label="Doğruluk" value={acc === null ? "—" : `%${acc}`} />
          <Stat label="Seri" value={`${save.streak}`} />
        </dl>

        <section>
          <h2 className="font-display text-xl">Rozetler</h2>
          <ul className="mt-3 space-y-2">
            {BADGES.map((b) => {
              const on = save.badges.includes(b.id);
              return (
                <li
                  key={b.id}
                  className={cn(
                    "rounded-xl px-4 py-3 shadow-[var(--shadow-border)]",
                    on ? "bg-surface" : "bg-raised/50 text-subtle",
                  )}
                >
                  <p className="text-sm font-medium">{b.name}</p>
                  <p className="text-xs text-muted">{b.blurb}</p>
                </li>
              );
            })}
          </ul>
        </section>

        <div className="grid grid-cols-2 gap-2">
          <Link to="/magaza">
            <Button variant="secondary" className="w-full">
              Mağaza
            </Button>
          </Link>
          <Link to="/yasal">
            <Button variant="secondary" className="w-full">
              Yasal
            </Button>
          </Link>
        </div>
        <p className="font-mono text-xs tabular-nums text-subtle">
          {formatXp(save.xp)} XP kayıtlı · yerel cihaz
        </p>
      </div>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface px-3 py-3 text-center shadow-[var(--shadow-border)]">
      <dt className="text-[11px] text-subtle">{label}</dt>
      <dd className="mt-1 font-mono text-lg tabular-nums">{value}</dd>
    </div>
  );
}
