import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getCase } from "@/data/cases";
import { scoreVerdict } from "@/lib/scoring";
import { useGame } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/vaka/$id/karar")({
  component: KararPage,
});

function KararPage() {
  const { id } = Route.useParams();
  const file = getCase(id);
  const nav = useNavigate();
  const save = useGame();
  const [suspect, setSuspect] = useState<string | null>(null);
  const [evidence, setEvidence] = useState<string | null>(null);
  const [conf, setConf] = useState(70);

  if (!file) return null;
  if (save.solved[file.id]) {
    return (
      <NavigateLike id={file.id} />
    );
  }

  function lock() {
    if (!file || !suspect || !evidence) return;
    const scored = scoreVerdict({
      file,
      suspectId: suspect,
      keyEvidenceId: evidence,
      confidence: conf,
      hintsUsed: save.hintsUsed[file.id] ?? 0,
      viewed: save.viewedEvidence[file.id] ?? [],
      pins: save.pins[file.id] ?? [],
    });
    save.lockVerdict(file.id, {
      ...scored,
      lockedAt: new Date().toISOString(),
    });
    nav({ to: "/vaka/$id/sonuc", params: { id: file.id } });
  }

  return (
    <div className="mx-auto min-h-dvh max-w-lg px-4 pb-28 pt-4">
      <button
        type="button"
        onClick={() => nav({ to: "/vaka/$id", params: { id: file.id } })}
        className="flex min-h-11 items-center gap-2 text-sm text-muted"
      >
        <ArrowLeft className="size-4" />
        Dosyaya dön
      </button>
      <p className="mt-4 font-mono text-[11px] tracking-[0.16em] text-ink">
        {file.number}
      </p>
      <h1 className="mt-1 font-display text-3xl">Kararını kilitle</h1>
      <p className="mt-2 text-sm text-muted">
        Bir kez kilitlenir. Çözüm ardından açılır. Bahis yoktur; yalnızca XP.
      </p>

      <h2 className="mt-8 font-display text-xl">Kim?</h2>
      <ul className="mt-3 space-y-2">
        {file.characters.map((c) => (
          <li key={c.id}>
            <button
              type="button"
              onClick={() => setSuspect(c.id)}
              className={cn(
                "flex w-full items-center justify-between rounded-xl px-4 py-3 text-left shadow-[var(--shadow-border)]",
                suspect === c.id ? "bg-accent text-accent-fg" : "bg-surface",
              )}
            >
              <span className="font-medium">{c.name}</span>
              <span
                className={cn(
                  "text-xs",
                  suspect === c.id ? "text-accent-fg/70" : "text-subtle",
                )}
              >
                {c.role}
              </span>
            </button>
          </li>
        ))}
      </ul>

      <h2 className="mt-8 font-display text-xl">En önemli delil</h2>
      <ul className="mt-3 space-y-2">
        {file.evidence.map((e) => (
          <li key={e.id}>
            <button
              type="button"
              onClick={() => setEvidence(e.id)}
              className={cn(
                "w-full rounded-xl px-4 py-3 text-left text-sm shadow-[var(--shadow-border)]",
                evidence === e.id ? "bg-accent text-accent-fg" : "bg-surface",
              )}
            >
              {e.title}
            </button>
          </li>
        ))}
      </ul>

      <h2 className="mt-8 font-display text-xl">Güven</h2>
      <div className="mt-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        <p className="font-mono text-sm tabular-nums text-muted">{conf}%</p>
        <input
          type="range"
          min={10}
          max={100}
          step={5}
          value={conf}
          onChange={(e) => setConf(Number(e.target.value))}
          className="mt-2 w-full accent-ink"
        />
      </div>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/95 px-4 py-3 backdrop-blur-md">
        <div className="mx-auto max-w-lg">
          <Button
            size="lg"
            className="w-full"
            disabled={!suspect || !evidence}
            onClick={lock}
          >
            Kararımı kilitle
          </Button>
        </div>
      </div>
    </div>
  );
}

function NavigateLike({ id }: { id: string }) {
  return (
    <div className="mx-auto max-w-lg px-4 py-16 text-center">
      <p className="text-muted">Bu dosya kilitlenmiş.</p>
      <Link
        to="/vaka/$id/sonuc"
        params={{ id }}
        className="mt-4 inline-block underline"
      >
        Sonuca git
      </Link>
    </div>
  );
}
