import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { CaseCard } from "@/components/case-card";
import { CASES } from "@/data/cases";
import { isUnlocked } from "@/lib/progress";
import { useGame } from "@/lib/store";

export const Route = createFileRoute("/vakalar")({ component: Vakalar });

function Vakalar() {
  const save = useGame();
  const free = CASES.filter((c) => !c.isPremium);
  const plus = CASES.filter((c) => c.isPremium);

  return (
    <AppShell>
      <div className="space-y-6">
        <header>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink">
            Arşiv
          </p>
          <h1 className="mt-1 font-display text-3xl">Vakalar</h1>
          <p className="mt-2 text-sm text-muted">
            Tüm dosyalar kurgusal Veyra evreninde hazırlandı. Kullanıcı vaka
            üretemez.
          </p>
        </header>
        <ul className="space-y-3">
          {free.map((file) => {
            const locked = !isUnlocked(file.id, save);
            const verdict = save.solved[file.id];
            return (
              <li key={file.id}>
                <CaseCard
                  file={file}
                  locked={locked}
                  solved={Boolean(verdict)}
                  correct={verdict?.correct}
                />
              </li>
            );
          })}
        </ul>
        <header className="pt-2">
          <h2 className="font-display text-2xl">Vaka Plus</h2>
          <p className="mt-1 text-sm text-muted">
            Abonelikle açılır. Rastgele kutu, bahis veya para ödülü yok.
          </p>
        </header>
        <ul className="space-y-3">
          {plus.map((file) => {
            const locked = !isUnlocked(file.id, save);
            const verdict = save.solved[file.id];
            return (
              <li key={file.id}>
                <CaseCard
                  file={file}
                  locked={locked}
                  solved={Boolean(verdict)}
                  correct={verdict?.correct}
                />
              </li>
            );
          })}
        </ul>
      </div>
    </AppShell>
  );
}
