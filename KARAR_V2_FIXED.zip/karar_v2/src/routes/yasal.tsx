import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { useGame } from "@/lib/store";

export const Route = createFileRoute("/yasal")({ component: Yasal });

function Yasal() {
  const reset = useGame((s) => s.resetSave);
  const [gone, setGone] = useState(false);

  return (
    <AppShell>
      <article className="space-y-8 text-sm leading-relaxed text-muted">
        <header>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink">
            Hukuk ve mali çerçeve
          </p>
          <h1 className="mt-1 font-display text-3xl text-fg">Yasal</h1>
        </header>

        <section className="space-y-2">
          <h2 className="font-display text-xl text-fg">Ne değildir</h2>
          <p>
            KARAR bir mahkeme, tahkim, şikâyet hattı veya haber platformu
            değildir. Gerçek kişi, şirket, olay veya suçlama kabul etmez.
            Kullanıcı vaka dosyası, fotoğraf, ses, belge veya ekran görüntüsü
            yükleyemez. Üçüncü kişiler hakkında içerik üretilemez.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="font-display text-xl text-fg">Kurgusal evren</h2>
          <p>
            Veyra, karakterler ve tüm vakalar önceden yazılmış kurgudur. İsim
            benzerlikleri tesadüftür. Topluluk teorileri yalnızca kurgusal
            dosyalar üzerinedir; gerçek ad, telefon, adres ve kurum yasaktır.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="font-display text-xl text-fg">Şans oyunu yok</h2>
          <p>
            7258 sayılı Kanun ve mağaza kumar yönergeleri kapsamında: para
            yatırıp vaka oynamak, XP'yi paraya çevirmek, ödüllü bahis,
            rastgele ücretli kutu yoktur. Vaka Plus bir dijital içerik
            aboneliğidir. Çerçeveler doğrudan kozmetik satıştır.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="font-display text-xl text-fg">Gizlilik (KVKK)</h2>
          <p>
            Bu sürüm hesap açmaz. İlerleme tarayıcının yerel deposunda kalır.
            Sunucuya ad, e-posta veya kimlik gönderilmez. Mağaza sürümünde
            Apple/Google satın alma fişleri ilgili mağazanın gizlilik
            politikasına tabidir. Reklam kimliği toplanmaz.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="font-display text-xl text-fg">Yaş</h2>
          <p>
            13+. Gizem teması vardır; şiddet, cinsel içerik ve gerçek suç
            tasviri yoktur. Çocuklara yönelik veri toplanmaz.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="font-display text-xl text-fg">Abonelik</h2>
          <p>
            Vaka Plus aylık dijital hizmettir. Otomatik yenilenir, mağaza
            hesabından iptal edilir. Teslim edilen dijital içerikte iade,
            Apple App Store / Google Play kurallarına ve 6502 sayılı Kanun'un
            dijital içerik istisnalarına tabidir. Fatura ve vergi yükümlülüğü
            yayıncıya aittir; oyuncu bahisle kazanç elde etmez.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="font-display text-xl text-fg">Sorumluluk</h2>
          <p>
            Oyun puanı, rütbe ve lig sıralaması eğlence amaçlıdır; hukuki
            sonuç doğurmaz. Kullanıcı, gerçek kişileri hedefleyen metin
            giremez. İhlalde içerik silinir, tekrarında erişim kapatılır.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="font-display text-xl text-fg">Verini sil</h2>
          <p>
            Hesap olmadığı için silme, bu cihazdaki kayıtların sıfırlanmasıdır.
          </p>
          {gone ? (
            <p className="text-ok">Kayıt silindi.</p>
          ) : (
            <Button
              variant="danger"
              onClick={() => {
                reset();
                setGone(true);
              }}
            >
              Yerel kaydı sil
            </Button>
          )}
        </section>

        <Link to="/" className="inline-block text-fg underline">
          Ana sayfa
        </Link>
      </article>
    </AppShell>
  );
}
