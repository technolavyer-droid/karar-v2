import { createFileRoute, Link } from "@tanstack/react-router";
import { BADGES } from "@/lib/badges";
import { Button } from "@/components/ui/button";
import { Seal } from "@/components/seal";
import { getCase } from "@/data/cases";
import { rankForXp } from "@/lib/ranks";
import { useGame } from "@/lib/store";
import { formatXp } from "@/lib/utils";

export const Route = createFileRoute("/vaka/$id/sonuc")({
  component: SonucPage,
});

function SonucPage() {
  const { id } = Route.useParams();
  const file = getCase(id);
  const save = useGame();
  const verdict = file ? save.solved[file.id] : undefined;

  if (!file || !verdict) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <p>Bu dosya henüz kilitlenmedi.</p>
        <Link to="/vaka/$id" params={{ id }} className="mt-4 inline-block underline">
          Dosyaya dön
        </Link>
      </div>
    );
  }

  const culprit = file.characters.find((c) => c.id === file.culpritId);
  const yours = file.characters.find((c) => c.id === verdict.suspectId);
  const rank = rankForXp(save.xp);
  const newBadges = save.badges
    .map((id) => BADGES.find((b) => b.id === id))
    .filter(Boolean);

  return (
    <div className="mx-auto min-h-dvh max-w-lg px-4 py-10">
      <div className="stagger-in space-y-6">
        <p className="font-mono text-[11px] tracking-[0.18em] text-ink">
          {file.number} kapandı
        </p>
        <div className="relative">
          <h1 className="font-display text-4xl">
            {verdict.correct
              ? "Doğru"
              : verdict.personCorrect
                ? "Kişi tuttu"
                : "Teorin tutmadı"}
          </h1>
          <div className="stamp-in pointer-events-none absolute -right-1 top-0 rotate-[-8deg] rounded-md border-2 border-ink/70 px-3 py-1 font-mono text-xs uppercase tracking-[0.2em] text-ink">
            Vaka çözüldü
          </div>
        </div>

        <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
          <p className="text-xs uppercase tracking-[0.14em] text-subtle">
            Dosyanın çözümü
          </p>
          <p className="mt-2 font-display text-2xl">{culprit?.name}</p>
          <p className="mt-3 text-sm leading-relaxed text-muted">{file.solution}</p>
          <p className="mt-4 text-sm italic text-fg/80">{file.closing}</p>
        </section>

        <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
          <p className="text-xs uppercase tracking-[0.14em] text-subtle">Sen</p>
          <p className="mt-2 text-sm">
            {yours?.name} · güven %{verdict.confidence}
          </p>
          <ul className="mt-4 space-y-2 text-sm">
            <Row
              label="Sonuç"
              value={verdict.correct ? "+100" : verdict.personCorrect ? "+70" : "+10"}
            />
            <Row label="Kritik delil" value={`${verdict.criticalFound}`} />
            <Row label="Çelişki" value={`${verdict.contradictions}`} />
            <Row label="İpucu" value={`${verdict.hintsUsed}`} />
            <Row label="Kazanılan XP" value={`+${formatXp(verdict.xpEarned)}`} strong />
          </ul>
        </section>

        <section className="flex items-center gap-3 rounded-xl bg-raised px-4 py-3">
          <Seal size={24} />
          <div>
            <p className="font-display text-lg">{rank.name}</p>
            <p className="font-mono text-xs tabular-nums text-muted">
              {formatXp(save.xp)} XP · seri {save.streak}
            </p>
          </div>
        </section>

        {newBadges.length > 0 && (
          <ul className="space-y-2">
            {newBadges.slice(-3).map((b) =>
              b ? (
                <li
                  key={b.id}
                  className="rounded-lg bg-surface px-4 py-3 text-sm shadow-[var(--shadow-border)]"
                >
                  <span className="font-medium">{b.name}</span>
                  <span className="text-muted"> — {b.blurb}</span>
                </li>
              ) : null,
            )}
          </ul>
        )}

        {file.hasSeal && (
          <p className="text-sm text-ink">
            Bu dosyada bir mühür izi vardı. Sezon ilerledikçe anlamı netleşir.
          </p>
        )}

        <div className="grid grid-cols-2 gap-2 pt-2">
          <Link to="/vakalar">
            <Button variant="secondary" className="w-full">
              Arşiv
            </Button>
          </Link>
          <Link to="/">
            <Button className="w-full">Bugün</Button>
          </Link>
        </div>
        <Link
          to="/teoriler"
          className="block text-center text-sm text-muted underline-offset-2 hover:underline"
        >
          Topluluk teorileri
        </Link>
      </div>
    </div>
  );
}

function Row({
  label,
  value,
  strong,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <li className="flex justify-between">
      <span className="text-muted">{label}</span>
      <span className={strong ? "font-medium tabular-nums" : "tabular-nums"}>
        {value}
      </span>
    </li>
  );
}
