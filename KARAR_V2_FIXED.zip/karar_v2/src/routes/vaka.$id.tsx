import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowLeft,
  Camera,
  Clock,
  FileText,
  KeyRound,
  Lightbulb,
  Lock,
  MessageSquare,
  Receipt,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { FictionBanner } from "@/components/disclaimer";
import { Seal } from "@/components/seal";
import { TheoryBoard } from "@/components/theory-board";
import {
  CATEGORY_LABEL,
  DIFFICULTY_LABEL,
  EVIDENCE_LABEL,
  getCase,
} from "@/data/cases";
import { isUnlocked } from "@/lib/progress";
import { useGame } from "@/lib/store";
import { cn } from "@/lib/utils";
import type { EvidenceKind } from "@/lib/types";

export const Route = createFileRoute("/vaka/$id")({ component: CasePage });

const TABS = [
  { id: "olay", label: "Olay" },
  { id: "kisiler", label: "Kişiler" },
  { id: "deliller", label: "Deliller" },
  { id: "zaman", label: "Zaman" },
  { id: "tahta", label: "Tahta" },
] as const;

const KIND_ICON: Record<EvidenceKind, typeof Camera> = {
  camera: Camera,
  statement: MessageSquare,
  physical: KeyRound,
  document: FileText,
  timeline: Clock,
  receipt: Receipt,
};

function CasePage() {
  const { id } = Route.useParams();
  const file = getCase(id);
  const nav = useNavigate();
  const save = useGame();
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("olay");
  const [openEv, setOpenEv] = useState<string | null>(null);
  const [hintOpen, setHintOpen] = useState(false);

  if (!file) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <p>Dosya bulunamadı.</p>
        <Link to="/vakalar" className="mt-4 inline-block underline">
          Arşive dön
        </Link>
      </div>
    );
  }

  const unlocked = isUnlocked(file.id, save);
  const verdict = save.solved[file.id];
  const viewed = save.viewedEvidence[file.id] ?? [];
  const hints = save.hintsUsed[file.id] ?? 0;
  const pins = save.pins[file.id] ?? [];

  if (!unlocked) {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-5">
        <Lock className="size-6 text-subtle" />
        <h1 className="mt-4 font-display text-3xl">{file.title}</h1>
        <p className="mt-2 text-muted">
          {file.isPremium
            ? "Bu dosya Vaka Plus aboneliğiyle açılır."
            : "Önceki dosyayı kilitlemeden bu vaka açılmaz."}
        </p>
        <div className="mt-6 flex gap-2">
          <Button variant="secondary" onClick={() => nav({ to: "/vakalar" })}>
            Arşiv
          </Button>
          {file.isPremium && (
            <Button onClick={() => nav({ to: "/magaza" })}>Vaka Plus</Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto min-h-dvh max-w-lg pb-28">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/90 px-4 py-3 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => nav({ to: "/" })}
            className="flex size-11 items-center justify-center rounded-md text-fg"
            aria-label="Geri"
          >
            <ArrowLeft className="size-5" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="font-mono text-[10px] tracking-[0.16em] text-ink">
              {file.number}
            </p>
            <h1 className="truncate font-display text-lg leading-tight">
              {file.title}
            </h1>
          </div>
          {file.hasSeal && <Seal size={20} />}
        </div>
        <div className="mt-3 flex gap-1 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={cn(
                "min-h-10 shrink-0 rounded-md px-3 text-sm",
                tab === t.id ? "bg-raised text-fg" : "text-muted",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      </header>

      <div className="px-4 pt-5">
        {tab === "olay" && (
          <div className="stagger-in space-y-5">
            <p className="text-sm text-muted">{file.location}</p>
            <div className="flex flex-wrap gap-2 text-[11px] text-subtle">
              <span className="rounded-sm bg-raised px-2 py-1">
                {CATEGORY_LABEL[file.category]}
              </span>
              <span className="rounded-sm bg-raised px-2 py-1">
                {DIFFICULTY_LABEL[file.difficulty]}
              </span>
              <span>
                {file.characters.length} kişi · {file.evidence.length} delil
              </span>
            </div>
            <div className="dossier-rule space-y-4 rounded-xl bg-surface p-5 text-[15px] leading-7 text-fg/90 shadow-[var(--shadow-border)]">
              {file.briefing.split("\n\n").map((p) => (
                <p key={p.slice(0, 24)}>{p}</p>
              ))}
            </div>
            <FictionBanner compact />
          </div>
        )}

        {tab === "kisiler" && (
          <ul className="space-y-3">
            {file.characters.map((c) => (
              <li
                key={c.id}
                className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]"
              >
                <div className="flex items-baseline justify-between gap-2">
                  <h2 className="font-display text-xl">{c.name}</h2>
                  <Users className="size-4 text-subtle" />
                </div>
                <p className="text-xs text-ink">{c.role}</p>
                <p className="mt-2 text-sm leading-relaxed text-muted">{c.bio}</p>
                <blockquote className="mt-3 border-l-2 border-ink/40 pl-3 text-sm leading-relaxed">
                  {c.statement}
                </blockquote>
              </li>
            ))}
          </ul>
        )}

        {tab === "deliller" && (
          <ul className="space-y-3">
            {file.evidence.map((e) => {
              const Icon = KIND_ICON[e.kind];
              const open = openEv === e.id;
              const seen = viewed.includes(e.id);
              return (
                <li key={e.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setOpenEv(open ? null : e.id);
                      save.markViewed(file.id, e.id);
                    }}
                    className="w-full rounded-xl bg-surface p-4 text-left shadow-[var(--shadow-border)]"
                  >
                    <div className="flex items-start gap-3">
                      <Icon className="mt-0.5 size-4 shrink-0 text-ink" />
                      <div className="min-w-0 flex-1">
                        <p className="text-[10px] uppercase tracking-[0.14em] text-subtle">
                          {EVIDENCE_LABEL[e.kind]}
                          {e.time ? ` · ${e.time}` : ""}
                          {!seen ? " · yeni" : ""}
                        </p>
                        <h2 className="font-display text-lg">{e.title}</h2>
                        {open && (
                          <p className="mt-2 text-sm leading-relaxed text-muted">
                            {e.body}
                          </p>
                        )}
                      </div>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        )}

        {tab === "zaman" && (
          <ol className="relative space-y-0 border-l border-line ml-2">
            {file.timeline.map((b) => (
              <li key={b.time + b.text} className="relative py-3 pl-5">
                <span className="absolute -left-1.5 top-5 size-3 rounded-full bg-ink" />
                <p className="font-mono text-xs text-ink">{b.time}</p>
                <p className="mt-1 text-sm leading-relaxed">{b.text}</p>
              </li>
            ))}
          </ol>
        )}

        {tab === "tahta" && (
          <TheoryBoard
            file={file}
            pins={pins}
            onChange={(p) => save.setPins(file.id, p)}
            readOnly={Boolean(verdict)}
          />
        )}
      </div>

      <div
        className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 px-4 py-3 backdrop-blur-md"
        style={{ paddingBottom: "max(12px, env(safe-area-inset-bottom))" }}
      >
        <div className="mx-auto flex max-w-lg gap-2">
          <Button
            variant="secondary"
            className="flex-1"
            onClick={() => setHintOpen(true)}
            disabled={Boolean(verdict) || hints >= 3}
          >
            <Lightbulb className="size-4" />
            İpucu {hints}/3
          </Button>
          {verdict ? (
            <Link to="/vaka/$id/sonuc" params={{ id: file.id }} className="flex-[2]">
              <Button className="w-full">Sonuç</Button>
            </Link>
          ) : (
            <Link to="/vaka/$id/karar" params={{ id: file.id }} className="flex-[2]">
              <Button className="w-full">Kararını ver</Button>
            </Link>
          )}
        </div>
      </div>

      {hintOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-2xl bg-surface p-5 shadow-[var(--shadow-border-hover)]">
            <h2 className="font-display text-2xl">Dosya asistanı</h2>
            <p className="mt-1 text-sm text-muted">
              Cevabı söylemez. Her ipucu kilitlemede XP düşürür.
            </p>
            <ol className="mt-4 space-y-3">
              {file.hints.map((h, i) => (
                <li
                  key={h}
                  className={cn(
                    "rounded-lg bg-raised p-3 text-sm leading-relaxed",
                    i < hints ? "text-fg" : "text-subtle",
                  )}
                >
                  <span className="font-mono text-[10px] text-ink">
                    İpucu {i + 1}
                  </span>
                  <p className="mt-1">{i < hints ? h : "Henüz açılmadı"}</p>
                </li>
              ))}
            </ol>
            <div className="mt-5 flex gap-2">
              <Button
                variant="secondary"
                className="flex-1"
                onClick={() => setHintOpen(false)}
              >
                Kapat
              </Button>
              {hints < 3 && !verdict && (
                <Button
                  className="flex-1"
                  onClick={() => save.useHint(file.id)}
                >
                  Sonrakini aç
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
