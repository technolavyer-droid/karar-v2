import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Seal } from "@/components/seal";
import { CASES } from "@/data/cases";
import { isUnlocked } from "@/lib/progress";
import { useGame } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/sezon")({ component: Sezon });

function Sezon() {
  const save = useGame();
  const done = CASES.filter((c) => save.solved[c.id]).length;

  return (
    <AppShell>
      <div className="space-y-6">
        <header className="flex items-start gap-3">
          <Seal size={32} />
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink">
              Sezon 1
            </p>
            <h1 className="font-display text-3xl">Veyra'nın Gölgesi</h1>
          </div>
        </header>
        <p className="text-sm leading-relaxed text-muted">
          On iki kurgusal dosya. Bazılarında aynı mühür belirir. Final, ilk
          gecedeki küçük ayrıntıya döner. {done}/{CASES.length} kapandı.
        </p>
        <ol className="space-y-2">
          {CASES.map((c) => {
            const locked = !isUnlocked(c.id, save);
            const solved = Boolean(save.solved[c.id]);
            return (
              <li key={c.id}>
                {locked ? (
                  <div className="flex items-center justify-between rounded-xl bg-raised/60 px-4 py-3 text-subtle">
                    <span className="text-sm">
                      {c.number} · {c.title}
                    </span>
                    <span className="text-[11px]">
                      {c.isPremium ? "Plus" : "Kilitli"}
                    </span>
                  </div>
                ) : (
                  <Link
                    to="/vaka/$id"
                    params={{ id: c.id }}
                    className={cn(
                      "flex items-center justify-between rounded-xl px-4 py-3 shadow-[var(--shadow-border)]",
                      solved ? "bg-surface" : "bg-raised",
                    )}
                  >
                    <span className="text-sm">
                      {c.number} · {c.title}
                    </span>
                    {c.hasSeal && <Seal size={16} />}
                  </Link>
                )}
              </li>
            );
          })}
        </ol>
      </div>
    </AppShell>
  );
}
