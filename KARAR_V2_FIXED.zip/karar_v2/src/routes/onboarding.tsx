import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { BookOpen, Search, Scale } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Seal } from "@/components/seal";
import { FictionBanner } from "@/components/disclaimer";
import { useGame } from "@/lib/store";

export const Route = createFileRoute("/onboarding")({
  component: Onboarding,
});

const STEPS = [
  {
    icon: BookOpen,
    title: "Oku",
    body: "Her gün kurgusal bir dosya açılır. Olayı, kişileri ve mekânı öğren.",
  },
  {
    icon: Search,
    title: "Ara",
    body: "Delilleri tart, zaman çizelgesini kur, çelişkiyi yakala.",
  },
  {
    icon: Scale,
    title: "Karar ver",
    body: "Teorini kilitle. Yanlış olabilirsin. Dikkatli okursan kazanırsın.",
  },
];

function Onboarding() {
  const nav = useNavigate();
  const confirmAge = useGame((s) => s.confirmAge);
  const complete = useGame((s) => s.completeOnboarding);
  const ageConfirmed = useGame((s) => s.ageConfirmed);
  const [name, setName] = useState("");
  const [step, setStep] = useState(0);

  if (!ageConfirmed) {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-5 py-10">
        <div className="stagger-in space-y-6">
          <Seal size={36} />
          <h1 className="font-display text-4xl">KARAR</h1>
          <p className="text-muted leading-relaxed">
            Bu bir oyundur. 13 yaşından küçükler oynayamaz. Kurgusal içerik,
            gerçek kişi yoktur. Bahis, para ödülü veya şans oyunu yoktur.
          </p>
          <FictionBanner />
          <Button
            size="lg"
            className="w-full"
            onClick={() => confirmAge()}
          >
            13 yaşından büyüğüm, devam
          </Button>
        </div>
      </div>
    );
  }

  if (step === 0) {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-5 py-10">
        <div className="stagger-in space-y-8">
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink">
            Bir dosyan var
          </p>
          <h1 className="font-display text-5xl leading-none">KARAR</h1>
          <p className="max-w-sm text-lg leading-relaxed text-muted">
            Dosyayı oku. Delilleri tart. Kendi teorini oluştur.
          </p>
          <Button size="lg" className="w-full" onClick={() => setStep(1)}>
            Başla
          </Button>
        </div>
      </div>
    );
  }

  if (step === 1) {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-5 py-10">
        <div className="stagger-in space-y-6">
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink">
            Nasıl oynanır
          </p>
          <ul className="space-y-4">
            {STEPS.map((s) => {
              const Icon = s.icon;
              return (
                <li
                  key={s.title}
                  className="flex gap-4 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]"
                >
                  <Icon className="mt-0.5 size-5 shrink-0 text-ink" />
                  <div>
                    <h2 className="font-display text-xl">{s.title}</h2>
                    <p className="mt-1 text-sm leading-relaxed text-muted">
                      {s.body}
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>
          <p className="text-sm text-muted">
            Yanlış karar verebilirsin. Dosyayı dikkatli okursan kazanırsın.
          </p>
          <Button size="lg" className="w-full" onClick={() => setStep(2)}>
            İsmini yaz
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-5 py-10">
      <div className="stagger-in space-y-6">
        <h1 className="font-display text-3xl">Arşivdeki adın</h1>
        <p className="text-sm text-muted">
          Gerçek adın olmak zorunda değil. Ligde bu görünür. Gerçek kişi adı
          kullanma.
        </p>
        <input
          value={name}
          onChange={(e) => setName(e.target.value.slice(0, 18))}
          placeholder="Analist"
          maxLength={18}
          className="h-12 w-full rounded-lg bg-raised px-4 text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle focus:shadow-[var(--shadow-border-hover)]"
        />
        <Button
          size="lg"
          className="w-full"
          onClick={() => {
            complete(name);
            nav({ to: "/vaka/$id", params: { id: "0001" } });
          }}
        >
          İlk dosyaya git
        </Button>
      </div>
    </div>
  );
}
