import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { useGame } from "@/lib/store";
import type { FrameId } from "@/lib/types";

export const Route = createFileRoute("/magaza")({ component: Magaza });

const FRAMES: { id: FrameId; name: string; price: string; blurb: string }[] = [
  { id: "dedektif", name: "Dedektif", price: "29,90 ₺", blurb: "Profil çerçevesi. Şans öğesi yok." },
  { id: "gizemci", name: "Gizemci", price: "29,90 ₺", blurb: "Profil çerçevesi. Doğrudan satın alma." },
  { id: "gece", name: "Gece Avcısı", price: "29,90 ₺", blurb: "Profil çerçevesi. İade: dijital içerik." },
];

function Magaza() {
  const save = useGame();
  const [confirm, setConfirm] = useState<"plus" | FrameId | null>(null);

  return (
    <AppShell>
      <div className="space-y-6">
        <header>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink">
            Dijital içerik
          </p>
          <h1 className="mt-1 font-display text-3xl">Mağaza</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Satın alımlar yalnızca kozmetik ve ek kurgusal vakadır. XP satın
            alınamaz. Bahis, kasa, rastgele kutu ve para ödülü yoktur. Web
            önizlemesinde ödeme simüle edilir; mağaza sürümünde Apple / Google
            faturalandırması kullanılır.
          </p>
        </header>

        <article className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
          <h2 className="font-display text-2xl">Vaka Plus</h2>
          <p className="mt-1 font-mono text-sm text-ink">79,90 ₺ / ay</p>
          <ul className="mt-3 list-disc space-y-1 pl-4 text-sm text-muted">
            <li>Ek kurgusal vakalar</li>
            <li>Reklamsız kullanım</li>
            <li>Gelişmiş teori tahtası</li>
          </ul>
          <p className="mt-3 text-xs text-subtle">
            Otomatik yenilenir. İstediğin zaman iptal. Dijital hizmet; teslim
            sonrası iade mağaza kurallarına tabidir.
          </p>
          {save.premium ? (
            <p className="mt-4 text-sm text-ok">Abonelik aktif (cihaz kaydı).</p>
          ) : (
            <Button className="mt-4 w-full" onClick={() => setConfirm("plus")}>
              Abone ol
            </Button>
          )}
        </article>

        <section>
          <h2 className="font-display text-xl">Çerçeveler</h2>
          <ul className="mt-3 space-y-3">
            {FRAMES.map((f) => {
              const owned = save.frames.includes(f.id);
              return (
                <li
                  key={f.id}
                  className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-medium">{f.name}</h3>
                      <p className="text-xs text-muted">{f.blurb}</p>
                    </div>
                    <span className="font-mono text-sm text-ink">{f.price}</span>
                  </div>
                  {owned ? (
                    <Button
                      variant={save.activeFrame === f.id ? "primary" : "secondary"}
                      size="sm"
                      className="mt-3"
                      onClick={() => save.setFrame(f.id)}
                    >
                      {save.activeFrame === f.id ? "Kullanılıyor" : "Kullan"}
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      className="mt-3"
                      onClick={() => setConfirm(f.id)}
                    >
                      Satın al
                    </Button>
                  )}
                </li>
              );
            })}
          </ul>
        </section>

        {confirm && (
          <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-4 sm:items-center">
            <div className="w-full max-w-md rounded-2xl bg-surface p-5">
              <h2 className="font-display text-2xl">Onay</h2>
              <p className="mt-2 text-sm text-muted">
                {confirm === "plus"
                  ? "Vaka Plus, 79,90 ₺ / ay. Şans unsuru yok. Bu önizlemede ödeme alınmaz, içerik cihazda açılır."
                  : "Kozmetik çerçeve, tek seferlik. Rastgele ödül yok. Bu önizlemede ödeme alınmaz."}
              </p>
              <div className="mt-5 flex gap-2">
                <Button
                  variant="secondary"
                  className="flex-1"
                  onClick={() => setConfirm(null)}
                >
                  Vazgeç
                </Button>
                <Button
                  className="flex-1"
                  onClick={() => {
                    if (confirm === "plus") save.buyPremium();
                    else save.buyFrame(confirm);
                    setConfirm(null);
                  }}
                >
                  Onayla
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
