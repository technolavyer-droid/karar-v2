import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { CASES } from "@/data/cases";
import { useGame } from "@/lib/store";

export const Route = createFileRoute("/teoriler")({ component: Teoriler });

const BLOCKED =
  /\b(\d{10,}|whatsapp|instagram|telegram|adres|telefon|tc\s?kimlik|@gmail|http)\b/i;

function Teoriler() {
  const save = useGame();
  const solved = CASES.filter((c) => save.solved[c.id]);
  const [active, setActive] = useState(solved[0]?.id ?? "");
  const file = CASES.find((c) => c.id === active);
  const note = file ? (save.notes[file.id] ?? "") : "";
  const [draft, setDraft] = useState(note);
  const [warn, setWarn] = useState("");

  function saveNote() {
    if (!file) return;
    if (BLOCKED.test(draft)) {
      setWarn("Gerçek kişi, iletişim veya bağlantı yazılamaz. Yalnızca kurgusal vaka.");
      return;
    }
    setWarn("");
    save.setNote(file.id, draft.slice(0, 280));
  }

  return (
    <AppShell>
      <div className="space-y-6">
        <header>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink">
            Kurgusal tartışma
          </p>
          <h1 className="mt-1 font-display text-3xl">Teoriler</h1>
          <p className="mt-2 text-sm text-muted">
            Spoiler koruması: yalnızca kapattığın dosyaların topluluk özeti
            görünür. İsimler kurgusaldır. Gerçek kişi hedeflemek yasaktır.
          </p>
        </header>
        {solved.length === 0 ? (
          <p className="text-sm text-muted">
            Henüz kilitlenmiş vaka yok.{" "}
            <Link to="/" className="underline">
              Günün dosyası
            </Link>
          </p>
        ) : (
          <>
            <div className="flex gap-2 overflow-x-auto">
              {solved.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setActive(c.id);
                    setDraft(save.notes[c.id] ?? "");
                    setWarn("");
                  }}
                  className="min-h-10 shrink-0 rounded-md bg-raised px-3 text-sm"
                >
                  {c.number}
                </button>
              ))}
            </div>
            {file && (
              <div className="space-y-4">
                <h2 className="font-display text-2xl">{file.title}</h2>
                <ul className="space-y-3">
                  {file.community.map((t) => {
                    const who = file.characters.find((c) => c.id === t.suspectId);
                    return (
                      <li
                        key={t.handle}
                        className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]"
                      >
                        <div className="flex items-baseline justify-between">
                          <p className="text-sm font-medium">{t.handle}</p>
                          <p className="font-mono text-xs text-ink">%{t.pct}</p>
                        </div>
                        <p className="mt-1 text-xs text-subtle">{who?.name}</p>
                        <p className="mt-2 text-sm leading-relaxed text-muted">
                          {t.text}
                        </p>
                      </li>
                    );
                  })}
                </ul>
                <div>
                  <label className="text-sm text-muted" htmlFor="note">
                    Senin teorin (yalnızca bu kurgusal vaka, 280 karakter)
                  </label>
                  <textarea
                    id="note"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value.slice(0, 280))}
                    rows={4}
                    className="mt-2 w-full rounded-xl bg-raised p-3 text-sm shadow-[var(--shadow-border)] outline-none"
                  />
                  {warn && <p className="mt-2 text-xs text-bad">{warn}</p>}
                  <Button className="mt-3" onClick={saveNote}>
                    Cihaza kaydet
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </AppShell>
  );
}
