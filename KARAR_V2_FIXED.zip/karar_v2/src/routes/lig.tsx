import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { weeklyBoard } from "@/data/league";
import { rankForXp } from "@/lib/ranks";
import { useGame } from "@/lib/store";
import { cn, formatXp } from "@/lib/utils";

export const Route = createFileRoute("/lig")({ component: Lig });

function Lig() {
  const save = useGame();
  const rows = weeklyBoard(save.xp, save.displayName);
  const you = rows.find((r) => r.you);

  return (
    <AppShell>
      <div className="space-y-6">
        <header>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink">
            Haftalık
          </p>
          <h1 className="mt-1 font-display text-3xl">Analist Ligi</h1>
          <p className="mt-2 text-sm text-muted">
            Sıralama yalnızca oyun XP'sidir. Gerçek para, bahis veya ödül
            yoktur. Diğer isimler kurgusal rakiplerdir.
          </p>
        </header>
        {you && (
          <p className="rounded-xl bg-raised px-4 py-3 text-sm shadow-[var(--shadow-border)]">
            Bu hafta {you.place}. sıradasın · {rankForXp(save.xp).name}
          </p>
        )}
        <ol className="space-y-1">
          {rows.map((r) => (
            <li
              key={r.handle + r.place}
              className={cn(
                "grid grid-cols-[2rem_1fr_auto] items-center gap-3 rounded-lg px-3 py-3",
                r.you ? "bg-surface shadow-[var(--shadow-border)]" : "",
              )}
            >
              <span className="font-mono text-sm tabular-nums text-subtle">
                {r.place}
              </span>
              <span className="truncate text-sm">
                {r.you ? `${r.handle} (sen)` : r.handle}
              </span>
              <span className="font-mono text-sm tabular-nums text-muted">
                {formatXp(r.xp)}
              </span>
            </li>
          ))}
        </ol>
      </div>
    </AppShell>
  );
}
