export interface Rival {
  handle: string;
  xp: number;
  rank: string;
}

export const RIVALS: Rival[] = [
  { handle: "SifirIz", xp: 2840, rank: "Usta" },
  { handle: "KayipMuhr", xp: 2710, rank: "Usta" },
  { handle: "GeceDefter", xp: 1980, rank: "Uzman" },
  { handle: "NotaKesen", xp: 1760, rank: "Uzman" },
  { handle: "CamYonu", xp: 1540, rank: "Dedektif" },
  { handle: "RihimTozu", xp: 1320, rank: "Dedektif" },
  { handle: "IkiSaat", xp: 1210, rank: "Dedektif" },
  { handle: "Fasikul", xp: 980, rank: "Analist" },
  { handle: "Yastik", xp: 740, rank: "Analist" },
  { handle: "IlkBakis", xp: 420, rank: "Gözlemci" },
];

export function weeklyBoard(playerXp: number, playerName: string) {
  const you = { handle: playerName || "Sen", xp: playerXp, rank: "Sen", you: true as const };
  const rows = [
    ...RIVALS.map((r) => ({ ...r, you: false as const })),
    you,
  ].sort((a, b) => b.xp - a.xp);
  return rows.map((r, i) => ({ ...r, place: i + 1 }));
}
