import { Link } from "@tanstack/react-router";

export function FictionBanner({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-subtle">
        Kurgusal evren · gerçek kişi yok
      </p>
    );
  }
  return (
    <aside className="rounded-xl bg-raised px-4 py-3 shadow-[var(--shadow-border)]">
      <p className="text-sm leading-relaxed text-muted">
        KARAR kurgusal bir oyundur. Veyra şehri, karakterler ve vakalar hayal
        ürünüdür. Gerçek kişi, kurum veya olay hakkında içerik üretilemez.
        Para ödülü, bahis veya şans oyunu yoktur.{" "}
        <Link to="/yasal" className="text-fg underline-offset-2 hover:underline">
          Yasal
        </Link>
      </p>
    </aside>
  );
}
