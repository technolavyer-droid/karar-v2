import { Link, useRouterState } from "@tanstack/react-router";
import { FileText, Scale, Trophy, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { Seal } from "./seal";

const NAV = [
  { to: "/", label: "Bugün", icon: Scale },
  { to: "/vakalar", label: "Vakalar", icon: FileText },
  { to: "/lig", label: "Lig", icon: Trophy },
  { to: "/profil", label: "Profil", icon: User },
] as const;

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hideNav =
    pathname.startsWith("/vaka/") ||
    pathname === "/onboarding" ||
    pathname === "/yasal";

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-lg items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2 text-fg">
            <Seal size={22} />
            <span className="font-display text-lg tracking-tight">KARAR</span>
          </Link>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-subtle">
            Veyra arşivi
          </p>
        </div>
      </header>
      <main
        className={cn(
          "mx-auto w-full max-w-lg px-4 pt-5",
          hideNav ? "pb-10" : "pb-28",
        )}
      >
        {children}
      </main>
      {!hideNav && (
        <nav
          className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-bg/95 backdrop-blur-md"
          style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
        >
          <ul className="mx-auto grid max-w-lg grid-cols-4">
            {NAV.map((item) => {
              const active =
                item.to === "/"
                  ? pathname === "/"
                  : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className={cn(
                      "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] tracking-wide",
                      active ? "text-fg" : "text-subtle",
                    )}
                  >
                    <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      )}
    </div>
  );
}
