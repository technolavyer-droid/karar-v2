import { formatXp } from "@/lib/utils";
import { nextRank, rankForXp, rankProgress } from "@/lib/ranks";

export function RankBar({ xp }: { xp: number }) {
  const rank = rankForXp(xp);
  const next = nextRank(xp);
  const p = Math.round(rankProgress(xp) * 100);
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <p className="font-display text-2xl">{rank.name}</p>
        <p className="font-mono text-sm tabular-nums text-muted">{formatXp(xp)} XP</p>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-raised">
        <div
          className="h-full rounded-full bg-ink transition-[width] duration-500"
          style={{ width: `${p}%` }}
        />
      </div>
      <p className="mt-2 text-xs text-subtle">
        {next ? `${next.name} için ${formatXp(next.minXp - xp)} XP` : "En üst rütbe"}
      </p>
    </div>
  );
}
