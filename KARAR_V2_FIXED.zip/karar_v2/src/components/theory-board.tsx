import { useMemo, useState } from "react";
import type { CaseFile, TheoryPin } from "@/lib/types";
import { EVIDENCE_LABEL } from "@/data/cases";
import { cn } from "@/lib/utils";
import { Button } from "./ui/button";

export function TheoryBoard({
  file,
  pins,
  onChange,
  readOnly,
}: {
  file: CaseFile;
  pins: TheoryPin[];
  onChange: (pins: TheoryPin[]) => void;
  readOnly?: boolean;
}) {
  const [held, setHeld] = useState<string | null>(null);

  const byChar = useMemo(() => {
    const map: Record<string, string[]> = {};
    for (const c of file.characters) map[c.id] = [];
    for (const p of pins) {
      if (map[p.characterId]) map[p.characterId].push(p.evidenceId);
    }
    return map;
  }, [file.characters, pins]);

  const assigned = new Set(pins.map((p) => p.evidenceId));
  const pool = file.evidence.filter((e) => !assigned.has(e.id));

  function assign(evidenceId: string, characterId: string) {
    if (readOnly) return;
    onChange([
      ...pins.filter((p) => p.evidenceId !== evidenceId),
      { evidenceId, characterId },
    ]);
    setHeld(null);
  }

  function unassign(evidenceId: string) {
    if (readOnly) return;
    onChange(pins.filter((p) => p.evidenceId !== evidenceId));
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">
        Delili seç, sonra bir isme bağla. Bu senin tahtan — doğru olmak zorunda
        değil, tutarlı olsun.
      </p>
      <div className="grid gap-3">
        {file.characters.map((c) => (
          <section
            key={c.id}
            className={cn(
              "rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]",
              held && !readOnly && "ring-1 ring-ink/40",
            )}
          >
            <button
              type="button"
              disabled={readOnly || !held}
              onClick={() => held && assign(held, c.id)}
              className="flex w-full items-baseline justify-between text-left"
            >
              <h3 className="font-display text-lg">{c.name}</h3>
              <span className="text-[11px] text-subtle">{c.role}</span>
            </button>
            <ul className="mt-2 flex flex-wrap gap-2">
              {byChar[c.id]?.length ? (
                byChar[c.id].map((eid) => {
                  const e = file.evidence.find((x) => x.id === eid);
                  if (!e) return null;
                  return (
                    <li key={eid}>
                      <button
                        type="button"
                        onClick={() => unassign(eid)}
                        className="rounded-sm bg-raised px-2 py-1 text-xs text-fg shadow-[var(--shadow-border)]"
                      >
                        {e.title}
                      </button>
                    </li>
                  );
                })
              ) : (
                <li className="text-xs text-subtle">Bağlı delil yok</li>
              )}
            </ul>
          </section>
        ))}
      </div>
      <div>
        <p className="mb-2 font-mono text-[11px] uppercase tracking-[0.16em] text-subtle">
          Atanmamış
        </p>
        <ul className="flex flex-wrap gap-2">
          {pool.map((e) => (
            <li key={e.id}>
              <Button
                type="button"
                variant={held === e.id ? "primary" : "secondary"}
                size="sm"
                onClick={() => setHeld(held === e.id ? null : e.id)}
                disabled={readOnly}
              >
                <span className="text-[10px] uppercase tracking-wider text-ink">
                  {EVIDENCE_LABEL[e.kind]}
                </span>
                {e.title}
              </Button>
            </li>
          ))}
          {pool.length === 0 && (
            <li className="text-sm text-muted">Tüm deliller bağlandı.</li>
          )}
        </ul>
      </div>
    </div>
  );
}
