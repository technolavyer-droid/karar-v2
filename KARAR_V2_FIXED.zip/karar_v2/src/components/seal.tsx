import { cn } from "@/lib/utils";

export function Seal({ className, size = 28 }: { className?: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      className={cn("text-ink", className)}
      aria-hidden
    >
      <circle cx="16" cy="16" r="13.5" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="16" cy="16" r="11" stroke="currentColor" strokeWidth="0.6" opacity="0.5" />
      <path
        d="M16 8.5 L21.5 18.5 H10.5 Z"
        stroke="currentColor"
        strokeWidth="1.2"
        fill="none"
      />
      <path d="M12 20.5 H20" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}
