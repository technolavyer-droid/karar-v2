import { useEffect } from "react";
import { useGame } from "@/lib/store";

/** Persist rehydrates after mount; never block the first paint with a splash. */
export function Gate({ children }: { children: React.ReactNode }) {
  const setHydrated = useGame((s) => s.setHydrated);

  useEffect(() => {
    const finish = () => {
      if (!useGame.getState().hydrated) setHydrated();
    };
    const unsub = useGame.persist.onFinishHydration(finish);
    if (useGame.persist.hasHydrated()) finish();
    const t = window.setTimeout(finish, 50);
    return () => {
      unsub();
      window.clearTimeout(t);
    };
  }, [setHydrated]);

  return <>{children}</>;
}
