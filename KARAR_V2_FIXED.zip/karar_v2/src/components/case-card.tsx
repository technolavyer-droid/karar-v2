import { Link } from "@tanstack/react-router";
import { Clock, Lock, Check } from "lucide-react";
import type { CaseFile } from "@/lib/types";
import { CATEGORY_LABEL, DIFFICULTY_LABEL } from "@/data/cases";
import { cn } from "@/lib/utils";

export function CaseCard({
  file,
  locked,
  solved,
  correct,
}: {
  file: CaseFile;
  locked?: boolean;
  solved?: boolean;
  correct?: boolean;
}) {
  const inner = (
    <article
      className={cn(
        "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150",
        !locked && "hover:shadow-[var(--shadow-border-hover)]",
        locked && "opacity-60",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-[11px] tracking-[0.16em] text-ink">
            {file.number}
          </p>
          <h3 className="mt-1 font-display text-xl leading-tight">{file.title}</h3>
        </div>
        {locked ? (
          <Lock className="size-4 shrink-0 text-subtle" />
        ) : solved ? (
          <Check className={cn("size-4 shrink-0", correct ? "text-ok" : "text-warn")} />
        ) : null}
      </div>
      <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted">
        {file.summary}
      </p>
      <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-subtle">
        <span className="rounded-sm bg-raised px-2 py-1">
          {CATEGORY_LABEL[file.category]}
        </span>
        <span className="rounded-sm bg-raised px-2 py-1">
          {DIFFICULTY_LABEL[file.difficulty]}
        </span>
        <span className="inline-flex items-center gap-1">
          <Clock className="size-3" />
          {file.durationMin} dk
        </span>
        {file.isPremium && <span className="text-ink">Vaka Plus</span>}
      </div>
    </article>
  );

  if (locked) return inner;
  return (
    <Link to="/vaka/$id" params={{ id: file.id }} className="block">
      {inner}
    </Link>
  );
}
