# KARAR — Release Checklist (re-audited 2026-08-29, Claude)

Bu dosya, önceki (grok/chatgpt) araçların ürettiği durum belgeleri **gerçek
kaynak koda karşı yeniden doğrulanarak** güncellenmiştir. Önceki raporlarda
"çözülmedi" denen bazı maddeler aslında bu ZIP'te çözülmüş bulundu; buna
karşılık önceki hiçbir raporda görünmeyen 1 gerçek bug ve 1 küçük veri
sızıntısı burada tespit edilip düzeltildi.

## Bu oturumda doğrulanan ve düzeltilen maddeler

- [x] **Import/referans grafiği** — 66 dosya taranarak (özyinelemeli, tüm
      relative import/dynamic import) sıfır çözümlenmemiş referans bulundu.
      Önceki raporlardaki "7 unresolved / 13 unresolved" kayıtları artık
      güncel değil — bu ZIP'te dosyaların hepsi (`gate-identity.server.ts`,
      `isolation.server.ts`, `verify.server.ts`, `routeTree.gen.ts` vb.)
      fiilen mevcut ve export/import isimleri eşleşiyor.
- [x] **GERÇEK BUG (yeni bulundu):** `src/routes/magaza.tsx` içinde
      `save.buyPremium()` çağrılıyordu ama bu fonksiyon `store.ts`'de hiç
      tanımlı değildi ve `GameState` tipinde de yoktu. Bu, `tsc` ve
      `vite build`'i kesin olarak kıracak bir hataydı — önceki hiçbir rapor
      bunu yakalamamış. `save-defaults.ts` ve `store.ts` içine eklendi, açık
      "PREVIEW-ONLY" uyarı yorumuyla işaretlendi.
- [x] **Ham hata sızıntısı (yeni bulundu):** `popup.server.ts`, OAuth
      başlatma hatasında `err.message`'ı doğrudan popup penceresine
      postMessage ile gönderiyordu. Artık sadece sunucu logunda tutuluyor,
      istemciye sabit `"oauth_init_threw"` kodu gidiyor.
- [x] `app-data/errors.ts` fallback dalı, sınıflandırılamayan hatanın ham
      `detail` metnini birincil kullanıcı mesajı olarak döndürüyordu; genel
      mesaja çevrildi (bu modül şu an başka hiçbir yerden import edilmiyor,
      bkz. aşağıdaki not).
- [x] Hard-coded secret taraması: 0 bulgu.
- [x] Legacy P2P/WebRTC/`/api/rtc` taraması: 0 bulgu.
- [x] `DEV_USER` / `DEV_USER_ID`: sadece `VITE_AUTH_ENABLED=false` iken
      devrede; `DATABASE_URL` set edilmişse `requireUserId()` fail-closed
      olarak reddediyor (paylaşımlı dev kimliğiyle gerçek veritabanına
      yazılmasını engelliyor). Kod seviyesinde risk düşük — asıl kontrol
      noktası prod ortam değişkenidir (aşağıya bakın).
- [x] Cross-site/sibling izolasyonu (`isolation.server.ts`) incelendi,
      `Sec-Fetch-Site`/`Sec-Fetch-Mode` tabanlı koruma doğru kurgulanmış.

## Yeni not: kullanılmayan ölü kod

`src/lib/app-data/*` (client.server.ts, errors.ts, login.ts, types.ts,
index.ts) hiçbir route veya component tarafından import edilmiyor —
uygulamanın kalanından tamamen kopuk bir şablon kalıntısı gibi görünüyor.
Zararı yok ama gereksiz yüzey alanı yaratıyor. Önerim: gerçekten kullanılmadığı
teyit edilirse (siz onaylayın) madde 30 kapsamında repodan çıkarılması.

## Bu ortamda doğrulanamayanlar (ağ erişimi kapalı / cihaz/hesap gerektirir)

- [ ] `npm ci` + gerçek `tsc --noEmit` + `eslint .` + `vite build` — bu
      sandbox'ın internet erişimi yok, `node_modules` kurulamıyor. Statik
      analiz (yukarıdaki import/tip taramaları) yapıldı ama bu, gerçek
      derleyici/lint çalıştırmanın yerini tutmaz. **Bunu kendi
      makinenizde/CI'da çalıştırıp sonucu bana yapıştırın, kalan hataları
      birlikte çözelim.**
- [ ] Apple StoreKit / Google Play Billing gerçek doğrulama
- [ ] Gerçek cihaz testleri (iOS/Android)
- [ ] Backend uçtan uca entegrasyon testi (gerçek DB + deploy ortamı)
- [ ] Penetrasyon/abuse testleri
- [ ] KVKK, tüketici hukuku, mali mevzuat, App Store/Play Store final onayı
      (hukuk/mali müşavir gerektirir — bir sonraki aşamada bakacağız)

Store'a submit etmeden önce yukarıdaki işaretsiz maddeler tamamlanmalı.
