export const migrations = [];
export const getMigrationPlan = () => [...migrations];
export default { migrations, getMigrationPlan };
