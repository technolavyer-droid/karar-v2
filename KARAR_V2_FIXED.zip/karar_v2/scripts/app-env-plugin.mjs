export default function appEnvPlugin() {
  return { name: "karar-app-env", config() { return {}; } };
}
