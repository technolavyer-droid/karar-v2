export const signOutPlan = {
  clearClientSession: true,
  revokeServerSession: true,
};
export default signOutPlan;
